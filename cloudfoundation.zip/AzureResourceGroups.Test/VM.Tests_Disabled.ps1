﻿Param(
  [string] [Parameter(Mandatory=$true)] $ResourceGroupName,
  [string] [Parameter(Mandatory=$true)] $Username,
  [string] [Parameter(Mandatory=$true)] $Password,
  [string] [Parameter(Mandatory=$true)] $TenantId,
  [string] [Parameter(Mandatory=$true)] $SubscriptionId,
  [string] [Parameter(Mandatory=$true)] $SrcDirectory,
  [string] [Parameter(Mandatory=$true)] $ArtifactsLocation,
  [string] [Parameter(Mandatory=$true)] $ArtifactsLocationSasToken
)

Describe "VM Deployment Tests" {
    # Init
    BeforeAll {
		$DebugPreference = "Continue"

		$SecurePassword = ConvertTo-SecureString -String $Password -AsPlainText -Force
		$cred = new-object -typename System.Management.Automation.PSCredential -argumentlist $Username, $SecurePassword
		Add-AzureRmAccount -Credential $cred -TenantId $TenantId -ServicePrincipal
		
		# Set subscription
		Set-AzureRmContext -SubscriptionId "$SubscriptionId"

		# Get content of parameter file
		$jsondata = Get-Content -Raw -Path $SrcDirectory\Azure_VM_OMS_Backup\azuredeploy.parameters.json | ConvertFrom-Json

		$jsondata.parameters._artifactsLocation.value = $ArtifactsLocation + "/Azure_VM_OMS_Backup"
		$jsondata.parameters._artifactsLocationSasToken.value = $ArtifactsLocationSasToken
		
		# Recreate parameter file with artifacts
		$hashtable=@{}
		$datajson = $jsondata.parameters | ConvertTo-Json | ConvertFrom-Json
		$datajson | Get-Member -MemberType NoteProperty | foreach { $hashtable.Add($_.Name,$datajson.($_.Name).value)}
    }

    # Teardown
    AfterAll {
		$DebugPreference = "SilentlyContinue"
    }

	Context "When VM deployed with parameters" {
    $output = Test-AzureRmResourceGroupDeployment `
              -ResourceGroupName $ResourceGroupName `
              -TemplateFile $SrcDirectory\Azure_VM_OMS_Backup\azuredeploy.json `
              -TemplateParameterObject $hashtable `
              -ErrorAction Stop `
               5>&1

	#Out-File -Append -FilePath C:\Temp\FailedTests.txt -InputObject $output

    $result = (($output[32] -split "Body:")[1] | ConvertFrom-Json).properties

    It "Should be deployed successfully" {
      $result.provisioningState | Should -Be "Succeeded"
    }

    It "Should have name of" {
		# Rebuild name according to naming conventions
		$expected = $jsondata.parameters.Zone.value + $jsondata.parameters.AppName.value + "-" + $jsondata.parameters.DNo.value
            
		$resource = $result.validatedResources[0]

		$resource.name | Should -Be $expected
    }
  }
    
}