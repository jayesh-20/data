﻿#
# This invokes pester test run.
#

Param(
    [string] [Parameter(Mandatory=$true)] $ResourceGroupName,
    [string] [Parameter(Mandatory=$true)] $TestFilePath,
    [string] [Parameter(Mandatory=$true)] $SrcDirectory,
    [string] [Parameter(Mandatory=$true)] $OutputDirectory,
    [string] [Parameter(Mandatory=$true)] $BuildNumber,
    [string] [Parameter(Mandatory=$true)] $Username,
    [string] [Parameter(Mandatory=$true)] $Password,
    [string] [Parameter(Mandatory=$true)] $TenantId,
	[string] [Parameter(Mandatory=$true)] $SubscriptionId,
	[string] [Parameter(Mandatory=$true)] $_artifactsLocation,
	[string] [Parameter(Mandatory=$true)] $_artifactsLocationSasToken
)

$outputFile = "$OutputDirectory\TEST-ARM-Pester-$BuildNumber.xml"

$parameters = @{ ResourceGroupName = $ResourceGroupName; SrcDirectory = $SrcDirectory; Username = $Username; Password = $Password; TenantId = $TenantId; SubscriptionId = $SubscriptionId; ArtifactsLocation = $_artifactsLocation; ArtifactsLocationSasToken = $_artifactsLocationSasToken }
$script = @{ Path = $TestFilePath; Parameters = $parameters }

$TestResults = Invoke-Pester -Script $script -OutputFile $outputFile -OutputFormat NUnitXml -PassThru

if($TestResults.FailedCount -gt 0)
{
    Write-Error "Failed '$($TestResults.FailedCount)' tests, build failed"
	exit ( [int]( -not $psake.build_success ) )
}