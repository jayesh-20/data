﻿Param(
  [string] [Parameter(Mandatory=$true)] $ResourceGroupName,
  [string] [Parameter(Mandatory=$true)] $Username,
  [string] [Parameter(Mandatory=$true)] $Password,
  [string] [Parameter(Mandatory=$true)] $TenantId,
  [string] [Parameter(Mandatory=$true)] $SubscriptionId,
  [string] [Parameter(Mandatory=$true)] $SrcDirectory,
  [string] [Parameter(Mandatory=$true)] $ArtifactsLocation,
  [string] [Parameter(Mandatory=$true)] $ArtifactsLocationSasToken
)

Describe "NIC Deployment Tests" {
    # Init
    BeforeAll {
		# Login and set subscription
		az login --service-principal -u $Username -p $Password -t $TenantId
		az account set --subscription $SubscriptionId
    }

    # Teardown
    AfterAll {
    }

    # Tests whether the cmdlet returns value or not.
    Context "When NIC deployed with parameters" {
        $output = az group deployment validate `
            -g $ResourceGroupName `
            --template-file $SrcDirectory\nic\azuredeploy.json `
            --parameters `@$SrcDirectory\nic\azuredeploy.parameters.json `
            | ConvertFrom-Json

        $result = $output.properties

		It "Should not have errors" {
			$output.error.details | Should -Be $null
		}

        It "Should be deployed successfully" {
            $result.provisioningState | Should -Be "Succeeded"
        }

        It "Should have name of" {
			# Get content of parameter file
			$jsondata = Get-Content -Raw -Path $SrcDirectory\nic\azuredeploy.parameters.json | ConvertFrom-Json

			# Rebuild name according to naming conventions
			$expected = $jsondata.parameters.AppName.value
            
			# Check if name of resource is the same as expected
			$resource = $result.validatedResources[0]
            $resource.name | Should -Be $expected
        }
    }
}