﻿Param(
  [string] [Parameter(Mandatory=$true)] $ResourceGroupName,
  [string] [Parameter(Mandatory=$true)] $Username,
  [string] [Parameter(Mandatory=$true)] $Password,
  [string] [Parameter(Mandatory=$true)] $TenantId,
  [string] [Parameter(Mandatory=$true)] $SubscriptionId,
  [string] [Parameter(Mandatory=$true)] $SrcDirectory,
  [string] [Parameter(Mandatory=$true)] $ArtifactsLocation,
  [string] [Parameter(Mandatory=$true)] $ArtifactsLocationSasToken
)

Describe "BackupVault Deployment Tests" {
    # Init
    BeforeAll {
		# Login and set subscription
		az login --service-principal -u $Username -p $Password -t $TenantId
		az account set --subscription $SubscriptionId
    }

    # Teardown
    AfterAll {
    }

    # Tests whether the cmdlet returns value or not.
    Context "When BackupVault deployed with parameters" {
        $output = az group deployment validate `
            -g $ResourceGroupName `
            --template-file $SrcDirectory\BackupVault\azuredeploy.json `
            --parameters `@$SrcDirectory\BackupVault\azuredeploy.parameters.json `
            | ConvertFrom-Json

        $result = $output.properties

		It "Should not have errors" {
			$output.error.details | Should -Be $null
		}

        It "Should be deployed successfully" {
            $result.provisioningState | Should -Be "Succeeded"
        }

        It "Should have name of" {
			# Get content of parameter file
			$jsondata = Get-Content -Raw -Path $SrcDirectory\BackupVault\azuredeploy.parameters.json | ConvertFrom-Json

			# Rebuild name according to naming conventions
			$expected = "vault-" + $jsondata.parameters.DName.value
            
			# Check if name of resource is the same as expected
			$resource = $result.validatedResources[0]
            $resource.name | Should -Be $expected
        }
    }
}