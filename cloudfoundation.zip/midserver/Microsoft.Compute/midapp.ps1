param (
    [string]$servicenowUrl,
    [string]$username,
    [string]$password,
    [string]$midServerName,
    [string]$midJavaAppLocation
)


#Create New Folder in C Drive
$Newfolder1 = mkdir "C:\MidServer"
$Newfolder = "C:\MidServer"
$URL = $midJavaAppLocation

Invoke-WebRequest -Uri $URL -OutFile "$Newfolder\ServiceNowMid.zip"

#Extract zip file into New folder
$fileName = "ServiceNowMid.zip"
$sourceFolder = "$Newfolder\$fileName"
Expand-Archive "$sourceFolder" -DestinationPath "$Newfolder"

$agentConfFileName = "$Newfolder\agent\config.xml"

#Replace URL,username,password
(Get-Content $agentConfFileName).replace('https://YOUR_INSTANCE.service-now.com', $servicenowUrl) | Set-Content $agentConfFileName
(Get-Content $agentConfFileName).replace('YOUR_INSTANCE_USER_NAME_HERE', $username) | Set-Content $agentConfFileName
(Get-Content $agentConfFileName).replace('YOUR_INSTANCE_PASSWORD_HERE', $password) | Set-Content $agentConfFileName
(Get-Content $agentConfFileName).replace('YOUR_MIDSERVER_NAME_GOES_HERE', $midServerName) | Set-Content $agentConfFileName


#Start the serviceNOW MID bat file
$scriptPath = "$Newfolder\agent\bin\mid.bat"
cmd.exe /c "$scriptPath start"